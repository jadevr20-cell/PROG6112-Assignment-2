/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package wildlifesa;

/**
 *
 * @author GHOST
 */
public class InjuredAnimalRescue extends RescueCase {
    private final String injuryDescription;
    private final double veterinaryTreatmentCost;
    private final boolean surgeryRequired;

    public InjuredAnimalRescue(
            String caseId,
            String animalName,
            String species,
            String rescueLocation,
            String assignedRanger,
            int rescueDays,
            double dailyCareCost,
            String injuryDescription,
            double veterinaryTreatmentCost,
            boolean surgeryRequired) {

        super(caseId, animalName, species, rescueLocation,
                assignedRanger, rescueDays, dailyCareCost);

        if (injuryDescription == null || injuryDescription.trim().isEmpty()) {
            throw new IllegalArgumentException("Injury description cannot be blank.");
        }
        if (veterinaryTreatmentCost <= 0) {
            throw new IllegalArgumentException(
                    "Veterinary treatment cost must be greater than zero.");
        }

        this.injuryDescription = injuryDescription.trim();
        this.veterinaryTreatmentCost = veterinaryTreatmentCost;
        this.surgeryRequired = surgeryRequired;
    }

    @Override
    public String getRescueType() {
        return "Injured Animal Rescue";
    }

    @Override
    public double calculateTotalCost() {
        double surgeryCost = surgeryRequired ? 5000.0 : 0.0;
        return getRescueDays() * getDailyCareCost()
                + veterinaryTreatmentCost + surgeryCost;
    }

    @Override
    public String determinePriority() {
        return surgeryRequired ? "Critical" : "High";
    }

    @Override
    public String getTypeSpecificInformation() {
        return String.format(
                "Injury: %s, Veterinary treatment: R%.2f, Surgery required: %s",
                injuryDescription, veterinaryTreatmentCost, surgeryRequired);
    }
}