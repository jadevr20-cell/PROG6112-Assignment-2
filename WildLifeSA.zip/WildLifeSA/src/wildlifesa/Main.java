/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package wildlifesa;

import java.util.Scanner;

/**
 *
 * @author GHOST
 */
public class Main {
    private static final Scanner INPUT = new Scanner(System.in);
    private static final RescueManager MANAGER = new RescueManager();


    /**
     * @param args the command line arguments
     */
     public static void main(String[] args) {
        boolean running = true;

        while (running) {
            displayMenu();
            int choice = readInt("Select an option: ");

            try {
                switch (choice) {
                    case 1:
                        createCase();
                        break;
                    case 2:
                        searchCase();
                        break;
                    case 3:
                        updateStatus();
                        break;
                    case 4:
                        displayAllCases();
                        break;
                    case 5:
                        System.out.println(MANAGER.generateReport());
                        break;
                    case 6:
                        running = false;
                        System.out.println("Goodbye.");
                        break;
                    default:
                        System.out.println("Invalid menu option. Choose 1 to 6.");
                }
            } catch (IllegalArgumentException ex) {
                System.out.println("Input error: " + ex.getMessage());
            }
        }
    }

    private static void displayMenu() {
        System.out.println("\n===== WILDLIFE SA RESCUE SYSTEM =====");
        System.out.println("1. Create Rescue Case");
        System.out.println("2. Search Rescue Case");
        System.out.println("3. Update Rescue Status");
        System.out.println("4. Display All Cases");
        System.out.println("5. Rescue Report");
        System.out.println("6. Exit");
    }

    private static void createCase() {
        System.out.println("\nRescue type:");
        System.out.println("1. Injured Animal");
        System.out.println("2. Orphaned Animal");
        System.out.println("3. Endangered Species");

        int type = readInt("Select rescue type: ");

        String caseId = readRequiredText("Rescue Case ID: ");
        String animalName = readRequiredText("Animal name: ");
        String species = readRequiredText("Species: ");
        String location = readRequiredText("Rescue location: ");
        String ranger = readRequiredText("Assigned ranger: ");
        int days = readPositiveInt("Number of rescue days: ");
        double dailyCost = readPositiveDouble("Daily care cost: ");

        RescueCase rescueCase;

        switch (type) {
            case 1:
                String injury = readRequiredText("Injury description: ");
                double veterinaryCost =
                        readPositiveDouble("Veterinary treatment cost: ");
                boolean surgery = readYesNo("Is surgery required? (y/n): ");

                rescueCase = new InjuredAnimalRescue(
                        caseId, animalName, species, location, ranger,
                        days, dailyCost, injury, veterinaryCost, surgery);
                break;

            case 2:
                int age = readPositiveInt("Estimated age in months: ");
                double feedingCost = readPositiveDouble("Feeding cost: ");
                boolean foster = readYesNo("Is foster care required? (y/n): ");

                rescueCase = new OrphanedAnimalRescue(
                        caseId, animalName, species, location, ranger,
                        days, dailyCost, age, feedingCost, foster);
                break;

            case 3:
                String classification =
                        readRequiredText("Conservation classification: ");
                double securityCost = readPositiveDouble("Security cost: ");
                boolean specialist =
                        readYesNo("Is a specialist team required? (y/n): ");

                rescueCase = new EndangeredSpeciesRescue(
                        caseId, animalName, species, location, ranger,
                        days, dailyCost, classification, securityCost, specialist);
                break;

            default:
                System.out.println("Invalid rescue type. Case was not created.");
                return;
        }

        MANAGER.addCase(rescueCase);
        System.out.println("Rescue case created successfully.");
        System.out.println(rescueCase.generateSummary());

        if (readYesNo("Start this rescue operation now? (y/n): ")) {
            rescueCase.startRescue();
            System.out.println("Rescue status updated to: "
                    + rescueCase.getStatus());
        }
    }

    private static void searchCase() {
        String id = readRequiredText("Enter Rescue Case ID: ");
        RescueCase rescueCase = MANAGER.findCase(id);

        if (rescueCase == null) {
            System.out.println("No rescue case found with that ID.");
        } else {
            System.out.println("\n" + rescueCase.getFullDetails());
        }
    }

    private static void updateStatus() {
        String id = readRequiredText("Enter Rescue Case ID: ");
        RescueCase rescueCase = MANAGER.findCase(id);

        if (rescueCase == null) {
            System.out.println("No rescue case found with that ID.");
            return;
        }

        System.out.println("1. Start rescue (Rescue in Progress)");
        System.out.println("2. Complete rescue (Completed)");
        System.out.println("3. Enter another status");

        int choice = readInt("Select an option: ");

        switch (choice) {
            case 1:
                rescueCase.startRescue();
                break;
            case 2:
                rescueCase.completeRescue();
                break;
            case 3:
                rescueCase.updateStatus(readRequiredText("Enter new status: "));
                break;
            default:
                System.out.println("Invalid status option.");
                return;
        }

        System.out.println("Status updated to: " + rescueCase.getStatus());
    }

    private static void displayAllCases() {
        if (MANAGER.getAllCases().isEmpty()) {
            System.out.println("There are no rescue cases.");
            return;
        }

        for (RescueCase rescueCase : MANAGER.getAllCases()) {
            System.out.println("\n" + rescueCase.getFullDetails());
        }
    }

    private static String readRequiredText(String prompt) {
        while (true) {
            System.out.print(prompt);
            String value = INPUT.nextLine().trim();

            if (!value.isEmpty()) {
                return value;
            }

            System.out.println("This value cannot be blank. Please try again.");
        }
    }

    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String value = INPUT.nextLine().trim();

            try {
                return Integer.parseInt(value);
            } catch (NumberFormatException ex) {
                System.out.println("Enter a whole number.");
            }
        }
    }

    private static int readPositiveInt(String prompt) {
        while (true) {
            int value = readInt(prompt);
            if (value > 0) {
                return value;
            }
            System.out.println("Enter a number greater than zero.");
        }
    }

    private static double readPositiveDouble(String prompt) {
        while (true) {
            System.out.print(prompt);
            String value = INPUT.nextLine().trim();

            try {
                double number = Double.parseDouble(value);
                if (Double.isFinite(number) && number > 0) {
                    return number;
                }
            } catch (NumberFormatException ex) {
                // Display the validation message below.
            }

            System.out.println("Enter a valid number greater than zero.");
        }
    }

    private static boolean readYesNo(String prompt) {
        while (true) {
            System.out.print(prompt);
            String value = INPUT.nextLine().trim();

            if (value.equalsIgnoreCase("y")
                    || value.equalsIgnoreCase("yes")) {
                return true;
            }
            if (value.equalsIgnoreCase("n")
                    || value.equalsIgnoreCase("no")) {
                return false;
            }

            System.out.println("Enter y or n.");
        }
    }
}
