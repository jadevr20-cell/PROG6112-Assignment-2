/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package wildlifesa;

/**
 *
 * @author GHOST
 */
public interface RescueOperations {
    void startRescue();
    void completeRescue();
    String generateSummary();
}
