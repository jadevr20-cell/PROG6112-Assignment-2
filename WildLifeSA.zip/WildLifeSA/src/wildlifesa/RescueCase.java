/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package wildlifesa;

/**
 *
 * @author GHOST
 */
public abstract class RescueCase implements RescueOperations {
    private final String caseId;
    private final String animalName;
    private final String species;
    private final String rescueLocation;
    private final String assignedRanger;
    private final int rescueDays;
    private final double dailyCareCost;

    private String status;

    protected RescueCase(
            String caseId,
            String animalName,
            String species,
            String rescueLocation,
            String assignedRanger,
            int rescueDays,
            double dailyCareCost) {

        this.caseId = requireText(caseId, "Rescue Case ID");
        this.animalName = requireText(animalName, "Animal name");
        this.species = requireText(species, "Species");
        this.rescueLocation = requireText(rescueLocation, "Rescue location");
        this.assignedRanger = requireText(assignedRanger, "Assigned ranger");

        if (rescueDays <= 0) {
            throw new IllegalArgumentException("Rescue days must be greater than zero.");
        }
        if (dailyCareCost <= 0) {
            throw new IllegalArgumentException("Daily care cost must be greater than zero.");
        }

        this.rescueDays = rescueDays;
        this.dailyCareCost = dailyCareCost;
        this.status = "Pending";
    }

    private static String requireText(String value, String fieldName) {
        if (value == null || value.trim().isEmpty()) {
            throw new IllegalArgumentException(fieldName + " cannot be blank.");
        }
        return value.trim();
    }

    public String getCaseId() {
        return caseId;
    }

    public String getAnimalName() {
        return animalName;
    }

    public String getSpecies() {
        return species;
    }

    public String getRescueLocation() {
        return rescueLocation;
    }

    public String getAssignedRanger() {
        return assignedRanger;
    }

    public int getRescueDays() {
        return rescueDays;
    }

    public double getDailyCareCost() {
        return dailyCareCost;
    }

    public String getStatus() {
        return status;
    }

    public void updateStatus(String newStatus) {
        if (newStatus == null || newStatus.trim().isEmpty()) {
            throw new IllegalArgumentException("Status cannot be blank.");
        }
        status = newStatus.trim();
    }

    public abstract String getRescueType();

    public abstract double calculateTotalCost();

    public abstract String determinePriority();

    public abstract String getTypeSpecificInformation();

    @Override
    public void startRescue() {
        updateStatus("Rescue in Progress");
    }

    @Override
    public void completeRescue() {
        updateStatus("Completed");
    }

    @Override
    public String generateSummary() {
        return String.format(
                "Case ID: %s | Type: %s | Species: %s | Ranger: %s"
                + " | Priority: %s | Status: %s | Total Cost: R%.2f",
                caseId,
                getRescueType(),
                species,
                assignedRanger,
                determinePriority(),
                status,
                calculateTotalCost());
    }

    public String getFullDetails() {
        return String.format(
                "Case ID: %s%n"
                + "Type: %s%n"
                + "Animal: %s%n"
                + "Species: %s%n"
                + "Location: %s%n"
                + "Ranger: %s%n"
                + "Rescue days: %d%n"
                + "Daily care cost: R%.2f%n"
                + "Priority: %s%n"
                + "Status: %s%n"
                + "Total cost: R%.2f%n"
                + "Additional information: %s",
                caseId,
                getRescueType(),
                animalName,
                species,
                rescueLocation,
                assignedRanger,
                rescueDays,
                dailyCareCost,
                determinePriority(),
                status,
                calculateTotalCost(),
                getTypeSpecificInformation());
    }

    public String getReportLine() {
        return String.format(
                "Case ID: %s | Type: %s | Species: %s | Location: %s"
                + " | Ranger: %s | Priority: %s | Status: %s"
                + " | Total Cost: R%.2f",
                caseId,
                getRescueType(),
                species,
                rescueLocation,
                assignedRanger,
                determinePriority(),
                status,
                calculateTotalCost());
    }
}
