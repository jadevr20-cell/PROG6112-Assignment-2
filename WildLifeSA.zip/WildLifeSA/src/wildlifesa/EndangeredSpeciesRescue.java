/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package wildlifesa;

/**
 *
 * @author GHOST
 */
public class EndangeredSpeciesRescue extends RescueCase {
    private final String conservationClassification;
    private final double securityCost;
    private final boolean specialistTeamRequired;

    public EndangeredSpeciesRescue(
            String caseId,
            String animalName,
            String species,
            String rescueLocation,
            String assignedRanger,
            int rescueDays,
            double dailyCareCost,
            String conservationClassification,
            double securityCost,
            boolean specialistTeamRequired) {

        super(caseId, animalName, species, rescueLocation,
                assignedRanger, rescueDays, dailyCareCost);

        if (conservationClassification == null
                || conservationClassification.trim().isEmpty()) {
            throw new IllegalArgumentException(
                    "Conservation classification cannot be blank.");
        }
        if (securityCost <= 0) {
            throw new IllegalArgumentException(
                    "Security cost must be greater than zero.");
        }

        this.conservationClassification = conservationClassification.trim();
        this.securityCost = securityCost;
        this.specialistTeamRequired = specialistTeamRequired;
    }

    @Override
    public String getRescueType() {
        return "Endangered Species Rescue";
    }

    @Override
    public double calculateTotalCost() {
        double specialistCost = specialistTeamRequired ? 8000.0 : 0.0;
        return getRescueDays() * getDailyCareCost()
                + securityCost + specialistCost;
    }

    @Override
    public String determinePriority() {
        return specialistTeamRequired ? "Critical" : "High";
    }

    @Override
    public String getTypeSpecificInformation() {
        return String.format(
                "Classification: %s, Security cost: R%.2f, Specialist team required: %s",
                conservationClassification, securityCost, specialistTeamRequired);
    }
}
