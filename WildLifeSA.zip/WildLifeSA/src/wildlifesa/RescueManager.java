/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package wildlifesa;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
/**
 *
 * @author GHOST
 */
public class RescueManager {
    private final ArrayList<RescueCase> rescueCases = new ArrayList<>();

    public void addCase(RescueCase rescueCase) {
        if (rescueCase == null) {
            throw new IllegalArgumentException("Rescue case cannot be null.");
        }

        if (findCase(rescueCase.getCaseId()) != null) {
            throw new IllegalArgumentException(
                    "A rescue case with ID " + rescueCase.getCaseId()
                    + " already exists.");
        }

        rescueCases.add(rescueCase);
    }

    public RescueCase findCase(String caseId) {
        if (caseId == null) {
            return null;
        }

        for (RescueCase rescueCase : rescueCases) {
            if (rescueCase.getCaseId().equalsIgnoreCase(caseId.trim())) {
                return rescueCase;
            }
        }
        return null;
    }

    public boolean updateStatus(String caseId, String status) {
        RescueCase rescueCase = findCase(caseId);
        if (rescueCase == null) {
            return false;
        }

        rescueCase.updateStatus(status);
        return true;
    }

    public List<RescueCase> getAllCases() {
        return Collections.unmodifiableList(rescueCases);
    }

    public String generateReport() {
        StringBuilder report = new StringBuilder();
        double totalCost = 0;

        report.append("\n========== WILDLIFE RESCUE REPORT ==========\n");

        for (RescueCase rescueCase : rescueCases) {
            report.append(rescueCase.getReportLine()).append("\n");
            totalCost += rescueCase.calculateTotalCost();
        }

        report.append("--------------------------------------------\n");
        report.append("Total rescue cases: ")
                .append(rescueCases.size()).append("\n");
        report.append(String.format("Total estimated rescue cost: R%.2f%n",
                totalCost));

        return report.toString();
    }
}