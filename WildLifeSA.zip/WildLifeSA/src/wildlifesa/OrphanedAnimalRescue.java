/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package wildlifesa;

/**
 *
 * @author GHOST
 */
public class OrphanedAnimalRescue extends RescueCase {
    private final int estimatedAgeMonths;
    private final double feedingCost;
    private final boolean fosterCareRequired;

    public OrphanedAnimalRescue(
            String caseId,
            String animalName,
            String species,
            String rescueLocation,
            String assignedRanger,
            int rescueDays,
            double dailyCareCost,
            int estimatedAgeMonths,
            double feedingCost,
            boolean fosterCareRequired) {

        super(caseId, animalName, species, rescueLocation,
                assignedRanger, rescueDays, dailyCareCost);

        if (estimatedAgeMonths <= 0) {
            throw new IllegalArgumentException(
                    "Estimated age must be greater than zero.");
        }
        if (feedingCost <= 0) {
            throw new IllegalArgumentException(
                    "Feeding cost must be greater than zero.");
        }

        this.estimatedAgeMonths = estimatedAgeMonths;
        this.feedingCost = feedingCost;
        this.fosterCareRequired = fosterCareRequired;
    }

    @Override
    public String getRescueType() {
        return "Orphaned Animal Rescue";
    }

    @Override
    public double calculateTotalCost() {
        double fosterCost = fosterCareRequired ? 2500.0 : 0.0;
        return getRescueDays() * getDailyCareCost()
                + feedingCost + fosterCost;
    }

    @Override
    public String determinePriority() {
        return estimatedAgeMonths <= 6 ? "High" : "Medium";
    }

    @Override
    public String getTypeSpecificInformation() {
        return String.format(
                "Estimated age: %d months, Feeding cost: R%.2f, Foster care required: %s",
                estimatedAgeMonths, feedingCost, fosterCareRequired);
    }
}
