/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package wildlifesa;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author GHOST
 */
public class RescueCaseIT {
    
    public RescueCaseIT() {
    }

    /**
     * Test of getCaseId method, of class RescueCase.
     */
    @Test
    public void testGetCaseId() {
        System.out.println("getCaseId");
        RescueCase instance = null;
        String expResult = "";
        String result = instance.getCaseId();
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    /**
     * Test of getAnimalName method, of class RescueCase.
     */
    @Test
    public void testGetAnimalName() {
        System.out.println("getAnimalName");
        RescueCase instance = null;
        String expResult = "";
        String result = instance.getAnimalName();
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    /**
     * Test of getSpecies method, of class RescueCase.
     */
    @Test
    public void testGetSpecies() {
        System.out.println("getSpecies");
        RescueCase instance = null;
        String expResult = "";
        String result = instance.getSpecies();
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    /**
     * Test of getRescueLocation method, of class RescueCase.
     */
    @Test
    public void testGetRescueLocation() {
        System.out.println("getRescueLocation");
        RescueCase instance = null;
        String expResult = "";
        String result = instance.getRescueLocation();
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    /**
     * Test of getAssignedRanger method, of class RescueCase.
     */
    @Test
    public void testGetAssignedRanger() {
        System.out.println("getAssignedRanger");
        RescueCase instance = null;
        String expResult = "";
        String result = instance.getAssignedRanger();
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    /**
     * Test of getRescueDays method, of class RescueCase.
     */
    @Test
    public void testGetRescueDays() {
        System.out.println("getRescueDays");
        RescueCase instance = null;
        int expResult = 0;
        int result = instance.getRescueDays();
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    /**
     * Test of getDailyCareCost method, of class RescueCase.
     */
    @Test
    public void testGetDailyCareCost() {
        System.out.println("getDailyCareCost");
        RescueCase instance = null;
        double expResult = 0.0;
        double result = instance.getDailyCareCost();
        assertEquals(expResult, result, 0);
        fail("The test case is a prototype.");
    }

    /**
     * Test of getStatus method, of class RescueCase.
     */
    @Test
    public void testGetStatus() {
        System.out.println("getStatus");
        RescueCase instance = null;
        String expResult = "";
        String result = instance.getStatus();
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    /**
     * Test of updateStatus method, of class RescueCase.
     */
    @Test
    public void testUpdateStatus() {
        System.out.println("updateStatus");
        String newStatus = "";
        RescueCase instance = null;
        instance.updateStatus(newStatus);
        fail("The test case is a prototype.");
    }

    /**
     * Test of getRescueType method, of class RescueCase.
     */
    @Test
    public void testGetRescueType() {
        System.out.println("getRescueType");
        RescueCase instance = null;
        String expResult = "";
        String result = instance.getRescueType();
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    /**
     * Test of calculateTotalCost method, of class RescueCase.
     */
    @Test
    public void testCalculateTotalCost() {
        System.out.println("calculateTotalCost");
        RescueCase instance = null;
        double expResult = 0.0;
        double result = instance.calculateTotalCost();
        assertEquals(expResult, result, 0);
        fail("The test case is a prototype.");
    }

    /**
     * Test of determinePriority method, of class RescueCase.
     */
    @Test
    public void testDeterminePriority() {
        System.out.println("determinePriority");
        RescueCase instance = null;
        String expResult = "";
        String result = instance.determinePriority();
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTypeSpecificInformation method, of class RescueCase.
     */
    @Test
    public void testGetTypeSpecificInformation() {
        System.out.println("getTypeSpecificInformation");
        RescueCase instance = null;
        String expResult = "";
        String result = instance.getTypeSpecificInformation();
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    /**
     * Test of startRescue method, of class RescueCase.
     */
    @Test
    public void testStartRescue() {
        System.out.println("startRescue");
        RescueCase instance = null;
        instance.startRescue();
        fail("The test case is a prototype.");
    }

    /**
     * Test of completeRescue method, of class RescueCase.
     */
    @Test
    public void testCompleteRescue() {
        System.out.println("completeRescue");
        RescueCase instance = null;
        instance.completeRescue();
        fail("The test case is a prototype.");
    }

    /**
     * Test of generateSummary method, of class RescueCase.
     */
    @Test
    public void testGenerateSummary() {
        System.out.println("generateSummary");
        RescueCase instance = null;
        String expResult = "";
        String result = instance.generateSummary();
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    /**
     * Test of getFullDetails method, of class RescueCase.
     */
    @Test
    public void testGetFullDetails() {
        System.out.println("getFullDetails");
        RescueCase instance = null;
        String expResult = "";
        String result = instance.getFullDetails();
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    /**
     * Test of getReportLine method, of class RescueCase.
     */
    @Test
    public void testGetReportLine() {
        System.out.println("getReportLine");
        RescueCase instance = null;
        String expResult = "";
        String result = instance.getReportLine();
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    public class RescueCaseImpl extends RescueCase {

        public RescueCaseImpl() {
            super("", "", "", "", "", 0, 0.0);
        }

        public String getRescueType() {
            return "";
        }

        public double calculateTotalCost() {
            return 0.0;
        }

        public String determinePriority() {
            return "";
        }

        public String getTypeSpecificInformation() {
            return "";
        }
    }
    
}
