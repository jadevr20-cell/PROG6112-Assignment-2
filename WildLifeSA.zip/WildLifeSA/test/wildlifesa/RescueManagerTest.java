/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package wildlifesa;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author GHOST
 */
public class RescueManagerTest {
    
    @Test
    public void injuredRescueCalculatesCostAndPriority() {
        InjuredAnimalRescue rescue = new InjuredAnimalRescue(
                "WR101", "Temba", "African Elephant",
                "Kruger", "Ranger Mokoena",
                3, 1000, "Leg injury", 2500, true);

        assertEquals(10500.0, rescue.calculateTotalCost(), 0.01);
        assertEquals("Critical", rescue.determinePriority());
    }

    @Test
    public void rescueStatusCanBeStartedAndCompleted() {
        RescueCase rescue = new InjuredAnimalRescue(
                "WR104", "Kito", "Lion",
                "Mpumalanga", "Ranger Smith",
                1, 500, "Paw injury", 1000, false);

        rescue.startRescue();
        assertEquals("Rescue in Progress", rescue.getStatus());

        rescue.completeRescue();
        assertEquals("Completed", rescue.getStatus());
    }

    @Test
    public void managerFindsCaseAndRejectsDuplicateId() {
        RescueManager manager = new RescueManager();

        RescueCase first = new InjuredAnimalRescue(
                "WR105", "Nala", "Cheetah",
                "Free State", "Ranger Adams",
                1, 500, "Cut", 1000, false);

        manager.addCase(first);
        assertSame(first, manager.findCase("WR105"));

        RescueCase duplicate = new InjuredAnimalRescue(
                "WR105", "Other", "Lion",
                "Free State", "Ranger Adams",
                1, 500, "Cut", 1000, false);

        try {
            manager.addCase(duplicate);
            fail("Expected duplicate ID to be rejected.");
        } catch (IllegalArgumentException expected) {
            // Test passes.
        }
    }
}
