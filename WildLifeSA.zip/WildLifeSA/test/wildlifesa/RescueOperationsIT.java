/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package wildlifesa;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author GHOST
 */
public class RescueOperationsIT {
    
    public RescueOperationsIT() {
    }

    /**
     * Test of startRescue method, of class RescueOperations.
     */
    @Test
    public void testStartRescue() {
        System.out.println("startRescue");
        RescueOperations instance = new RescueOperationsImpl();
        instance.startRescue();
        fail("The test case is a prototype.");
    }

    /**
     * Test of completeRescue method, of class RescueOperations.
     */
    @Test
    public void testCompleteRescue() {
        System.out.println("completeRescue");
        RescueOperations instance = new RescueOperationsImpl();
        instance.completeRescue();
        fail("The test case is a prototype.");
    }

    /**
     * Test of generateSummary method, of class RescueOperations.
     */
    @Test
    public void testGenerateSummary() {
        System.out.println("generateSummary");
        RescueOperations instance = new RescueOperationsImpl();
        String expResult = "";
        String result = instance.generateSummary();
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    public class RescueOperationsImpl implements RescueOperations {

        public void startRescue() {
        }

        public void completeRescue() {
        }

        public String generateSummary() {
            return "";
        }
    }
    
}
