/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package wildlifesa;

import java.util.List;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author GHOST
 */
public class RescueManagerIT {
    
    public RescueManagerIT() {
    }

    /**
     * Test of addCase method, of class RescueManager.
     */
    @Test
    public void testAddCase() {
        System.out.println("addCase");
        RescueCase rescueCase = null;
        RescueManager instance = new RescueManager();
        instance.addCase(rescueCase);
        fail("The test case is a prototype.");
    }

    /**
     * Test of findCase method, of class RescueManager.
     */
    @Test
    public void testFindCase() {
        System.out.println("findCase");
        String caseId = "";
        RescueManager instance = new RescueManager();
        RescueCase expResult = null;
        RescueCase result = instance.findCase(caseId);
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    /**
     * Test of updateStatus method, of class RescueManager.
     */
    @Test
    public void testUpdateStatus() {
        System.out.println("updateStatus");
        String caseId = "";
        String status = "";
        RescueManager instance = new RescueManager();
        boolean expResult = false;
        boolean result = instance.updateStatus(caseId, status);
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    /**
     * Test of getAllCases method, of class RescueManager.
     */
    @Test
    public void testGetAllCases() {
        System.out.println("getAllCases");
        RescueManager instance = new RescueManager();
        List<RescueCase> expResult = null;
        List<RescueCase> result = instance.getAllCases();
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    /**
     * Test of generateReport method, of class RescueManager.
     */
    @Test
    public void testGenerateReport() {
        System.out.println("generateReport");
        RescueManager instance = new RescueManager();
        String expResult = "";
        String result = instance.generateReport();
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }
    
}
