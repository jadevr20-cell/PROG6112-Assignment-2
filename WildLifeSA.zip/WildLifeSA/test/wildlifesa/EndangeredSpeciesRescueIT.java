/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package wildlifesa;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author GHOST
 */
public class EndangeredSpeciesRescueIT {
    
    public EndangeredSpeciesRescueIT() {
    }

    /**
     * Test of getRescueType method, of class EndangeredSpeciesRescue.
     */
    @Test
    public void testGetRescueType() {
        System.out.println("getRescueType");
        EndangeredSpeciesRescue instance = null;
        String expResult = "";
        String result = instance.getRescueType();
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    /**
     * Test of calculateTotalCost method, of class EndangeredSpeciesRescue.
     */
    @Test
    public void testCalculateTotalCost() {
        System.out.println("calculateTotalCost");
        EndangeredSpeciesRescue instance = null;
        double expResult = 0.0;
        double result = instance.calculateTotalCost();
        assertEquals(expResult, result, 0);
        fail("The test case is a prototype.");
    }

    /**
     * Test of determinePriority method, of class EndangeredSpeciesRescue.
     */
    @Test
    public void testDeterminePriority() {
        System.out.println("determinePriority");
        EndangeredSpeciesRescue instance = null;
        String expResult = "";
        String result = instance.determinePriority();
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }

    /**
     * Test of getTypeSpecificInformation method, of class EndangeredSpeciesRescue.
     */
    @Test
    public void testGetTypeSpecificInformation() {
        System.out.println("getTypeSpecificInformation");
        EndangeredSpeciesRescue instance = null;
        String expResult = "";
        String result = instance.getTypeSpecificInformation();
        assertEquals(expResult, result);
        fail("The test case is a prototype.");
    }
    
}
