/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4Suite.java to edit this template
 */
package wildlifesa;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

/**
 *
 * @author GHOST
 */
@RunWith(Suite.class)
@Suite.SuiteClasses({wildlifesa.RescueManagerIT.class, wildlifesa.OrphanedAnimalRescueIT.class, wildlifesa.InjuredAnimalRescueIT.class, wildlifesa.RescueOperationsIT.class, wildlifesa.EndangeredSpeciesRescueIT.class, wildlifesa.MainIT.class, wildlifesa.RescueCaseIT.class})
public class WildlifesaITSuite {
    
}
